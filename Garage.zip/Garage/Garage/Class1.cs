using System.ComponentModel;

namespace Garage
{
  public class ParkingSpot
  { 
    public string? licensePLate { get; set; }
    public DateTime entryDate { get; set; }
  }
  public class Garage
  {
    public ParkingSpot[] parkingSpots { get; } = new ParkingSpot[50];

    public bool IsOccupied(int parkSpotNumber)
    {
      if (parkingSpots[parkSpotNumber] != null)
      {
        return true;
      }
      else
      {
        return false;
      }
    }
    
    public bool TryExit(int parkSpotNumber, DateTime exitTime, out decimal costs)
    {
      int minutes = 0;
      minutes = exitTime.Minute - parkingSpots[parkSpotNumber].entryDate.Minute;  
      if (parkingSpots[parkSpotNumber] != null)
      {
        parkingSpots[parkSpotNumber] = null;
        if (minutes <= 15)
        {
          costs = 0;
        }
        else
        {
          costs = (minutes / 30) * 3;
        }
        return true;
      }
      else
      {
        costs = 0;
        return false;
      }
    }
    public bool TryOccupy(int parkSpotNumber, string plate, DateTime entryTime)
    {
      if (parkingSpots[parkSpotNumber] == null )
      {
        parkingSpots[parkSpotNumber].licensePLate = plate;
        parkingSpots[parkSpotNumber].entryDate = entryTime;
        return true;
      }
      else
      {
        return false;
      }     
    }
    public void GenerateReport()
    {
        Console.WriteLine("| Spot | License Plate |");
        Console.WriteLine("| ---- | ------------- |");
        for (int i = 0; i < 50; i++)
        {
          Console.WriteLine($"| {parkingSpots[i]} | {parkingSpots[i].licensePLate}"  );
        }
      }     
    }
  }


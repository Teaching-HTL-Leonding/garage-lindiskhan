using System;
using System.ComponentModel.Design;
using Garage;

namespace Garage.App
{
  class Program
  {
    public static void Main()
    {  
      var gar = new Garage();
      var parkspot = new ParkingSpot();
      int parkSpotNumber = 0;
      string plate;
      int slctn = 0;
      DateTime entry;
      DateTime exit;

      Console.WriteLine("Choose:  ");
      Console.WriteLine("[1] Enter a car entry ");
      Console.WriteLine("[2] Enter a car exit ");
      Console.WriteLine("[3] Generate report ");
      Console.WriteLine("[4] Exit");
      
      while (slctn != 4)
      {
        Console.WriteLine("Selection: ");
        slctn = int.Parse(Console.ReadLine()!);
        if (slctn == 1)
        {
          Console.Write("Enter parking spot number: ");
          parkSpotNumber = int.Parse(Console.ReadLine()!);

          Console.Write("Enter license plate: ");
          plate = Console.ReadLine();

          Console.WriteLine("Enter entry DateTime: ");
          entry = Convert.ToDateTime(Console.ReadLine());

          gar.TryOccupy(parkSpotNumber, plate, entry);

        }
        else if (slctn == 4)
        {
          Console.WriteLine("Bye!");
        }
        else if (slctn == 3)
        {
          gar.GenerateReport();
        }
        else
        {
          Console.WriteLine("Error");
        }
      }
    }
  }
}
